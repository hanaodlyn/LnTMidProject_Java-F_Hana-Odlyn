import java.util.Scanner;
import java.util.Formatter;
public class Main{
    
    static void menu (){
        System.out.println("1. Input Data Karyawan");
        System.out.println("2. View Data Karyawan");
        System.out.println("3. Remove Data Karyawan");
        System.out.println("4. Exit");
        System.out.print("Choose: ");
        
    }
    
    static void view (String name[], String gender[], String jabatan[], int age[], int counter){
        Formatter fmt = new Formatter();
        
        fmt.format("%s %s %s %s %s\n", "No.","Name", "Gender", "Jabatan", "Age");
        
        for(int i=0;i<counter;i++){
            fmt.format("%s %s %s %s %s", i+1,name[i], gender[i], jabatan[i], age[i]);
                        // System.out.println(i+1);
                        // System.out.println(name[i]);
                        // System.out.println(gender[i]);
                        // System.out.println(address[i]);
                        // System.out.println(age[i]);
                    }
        System.out.println(fmt);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int input;
        
        String name[] = new String[100];
        String gender[] = new String[100];
        String jabatan[] = new String[100];
        int age[] = new int[100];
        
        int counter = 0;
        
        do{
            menu();
            input = sc.nextInt();
            
            switch(input){
            case 1:
                //menu 1
                System.out.println("Input Data");
                Scanner sc1 = new Scanner(System.in);
                String input_name;
                String split_name[];
                String input_gender;
                String input_jabatan;
                int input_age;
                do{
                    System.out.print("Input name:");
                    input_name = sc1.nextLine();
                    // " maxine keith  "
                    // trim -> "maxin keith" // remove whitespace
                    // split -> [maxin, keith] // split string, result in form of array
                    split_name = input_name.trim().split(" ");
    
                }while(
                    (input_name.length() < 5 || input_name.length() > 20) || 
                    
                    split_name.length < 2 // check how many words
                );
                
                do{
                    System.out.print("Input gender [laki-laki|perempuan]: ");
                    input_gender = sc1.nextLine();
                } while(!input_gender.equals("laki-laki") && !input_gender.equals("perempuan")
                );
                
                do{
                System.out.print("Input jabatan [Manager | Supervisor | Admin]: ");
                input_jabatan = sc1.nextLine();
                } while(!input_jabatan.equals("Manager") && !input_jabatan.equals("Supervisor") && !input_jabatan.equals("Admin")
                );
                
                do{
                    System.out.print("Input age: ");
                    input_age = sc1.nextInt();
                }while(input_age < 17 || input_age > 30);
                // [max, keith]
                // = max.touppercase -> MAX.charAt(0) -> M -> char
                for(int i=0;i<split_name.length;i++){
                    System.out.print(split_name[i].toUpperCase().charAt(0));
                }
                
                name[counter] = input_name;
                gender[counter] = input_gender;
                jabatan[counter] = input_jabatan;
                age[counter] = input_age;
                counter++;
            
                for(int i=0;i<counter-1;i++){
                    for(int j = 0; j<counter-i-1;j++){
                        if(name[j].compareTo(name[j+1]) > 0){
                            String temp = name[j];
                            name[j] = name[j+1];
                            name[j+1] = temp;
                            
                            String temp_gender = gender[j];
                            gender[j] = gender[j+1];
                            gender[j+1] = temp_gender;
                            
                            String temp_jabatan = jabatan[j];
                            jabatan[j] = jabatan[j+1];
                            jabatan[j+1] = temp_jabatan;
                            
                            int temp_age = age[j];
                            age[j] = age[j+1];
                            age[j+1] = temp_age;
                            
                        }
                        
                    }
                }
                                 
                                
                
                break;
            case 2:
                // menu 2
                
                System.out.println("View Data");
                if(counter == 0){
                    System.out.println("No Data");
                }
                else{
                    view(name,gender,jabatan,age, counter);
                }
                break;
            case 3: 
                // menu 3
                System.out.println("Remove Data");
                 if(counter == 0){
                    System.out.println("No Data");
                }
                else{
                    view(name,gender,jabatan,age, counter);
                }
                
                Scanner sc2 = new Scanner(System.in);
                // do{
                System.out.print("Input number: ");
                int input_delete = sc2.nextInt();
                    if(input_delete == 0){
                        break;
                    }
                int delete_array = input_delete - 1;
                // }while();
                // array= [1,2,3,4,5] = 4
                // array= [1,2,4,5,5] = 4
                // counter --;
                // counter= 3
                // array = [1,2,4,5]
                
                for(int i= delete_array; i<counter-1; i++){
                    name[i] = name[i+1];
                    gender[i] = gender[i+1];
                    jabatan[i] = jabatan[i+1];
                    age[i] = age[i+1];
                }
                
                counter --;
                System.out.println("Successfully deleted");
                
                break;
            case 4:
                break;
            // switch case
            // 1 ke menu yg mana, dst
            }
        }while(input != 4);
        
    }}
